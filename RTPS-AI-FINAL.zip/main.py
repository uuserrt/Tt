
from flask import Flask, render_template, request, redirect, send_file
app = Flask(__name__)

@app.route('/')
def index():
    return "RTPS-AI Home Page (Auto Aadhaar Fill + Certificate Generator)"

if __name__ == '__main__':
    app.run(debug=True)
