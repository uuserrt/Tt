
# RTPS-AI Project

This project simulates RTPS certificate generation (Caste, Income, Residence)
with auto form-filling from Aadhaar OCR and photo upload.

## Features:
- Aadhaar OCR Autofill
- Photo Upload
- Officer Approval Simulation
- PDF Certificate Generator
- Token ID Download System
